﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelBankomatData = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxPIN = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonPIN = new System.Windows.Forms.Button();
            this.buttonDown = new System.Windows.Forms.Button();
            this.buttonLoadSum = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.tBTen1 = new System.Windows.Forms.TextBox();
            this.tBten5 = new System.Windows.Forms.TextBox();
            this.tBhun1 = new System.Windows.Forms.TextBox();
            this.tBhun5 = new System.Windows.Forms.TextBox();
            this.tBthous = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // labelBankomatData
            // 
            this.labelBankomatData.AutoSize = true;
            this.labelBankomatData.Location = new System.Drawing.Point(17, 15);
            this.labelBankomatData.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelBankomatData.Name = "labelBankomatData";
            this.labelBankomatData.Size = new System.Drawing.Size(100, 13);
            this.labelBankomatData.TabIndex = 0;
            this.labelBankomatData.Text = "labelBankomatData";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(272, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Управление банкоматом";
            // 
            // textBoxPIN
            // 
            this.textBoxPIN.Location = new System.Drawing.Point(372, 51);
            this.textBoxPIN.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPIN.Name = "textBoxPIN";
            this.textBoxPIN.Size = new System.Drawing.Size(101, 20);
            this.textBoxPIN.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(369, 35);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "PIN-код";
            // 
            // buttonPIN
            // 
            this.buttonPIN.Location = new System.Drawing.Point(264, 51);
            this.buttonPIN.Margin = new System.Windows.Forms.Padding(2);
            this.buttonPIN.Name = "buttonPIN";
            this.buttonPIN.Size = new System.Drawing.Size(104, 20);
            this.buttonPIN.TabIndex = 5;
            this.buttonPIN.Text = "Ввести PIN-код";
            this.buttonPIN.Click += new System.EventHandler(this.buttonPIN_Click);
            // 
            // buttonDown
            // 
            this.buttonDown.Location = new System.Drawing.Point(264, 91);
            this.buttonDown.Margin = new System.Windows.Forms.Padding(2);
            this.buttonDown.Name = "buttonDown";
            this.buttonDown.Size = new System.Drawing.Size(104, 21);
            this.buttonDown.TabIndex = 3;
            this.buttonDown.Text = "Снять сумму";
            this.buttonDown.UseVisualStyleBackColor = true;
            this.buttonDown.Click += new System.EventHandler(this.buttonDown_Click);
            // 
            // buttonLoadSum
            // 
            this.buttonLoadSum.Location = new System.Drawing.Point(565, 91);
            this.buttonLoadSum.Margin = new System.Windows.Forms.Padding(2);
            this.buttonLoadSum.Name = "buttonLoadSum";
            this.buttonLoadSum.Size = new System.Drawing.Size(119, 37);
            this.buttonLoadSum.TabIndex = 3;
            this.buttonLoadSum.Text = "Загрузить деньги /Разблокировать";
            this.buttonLoadSum.UseVisualStyleBackColor = true;
            this.buttonLoadSum.Click += new System.EventHandler(this.buttonLoadSum_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Location = new System.Drawing.Point(264, 129);
            this.buttonStop.Margin = new System.Windows.Forms.Padding(2);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(104, 41);
            this.buttonStop.TabIndex = 4;
            this.buttonStop.Text = "Завершить работу";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(377, 95);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(38, 17);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "10";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(377, 121);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(38, 17);
            this.checkBox2.TabIndex = 7;
            this.checkBox2.Text = "50";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(377, 148);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(44, 17);
            this.checkBox3.TabIndex = 8;
            this.checkBox3.Text = "100";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(377, 175);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(44, 17);
            this.checkBox4.TabIndex = 9;
            this.checkBox4.Text = "500";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(377, 202);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(50, 17);
            this.checkBox5.TabIndex = 10;
            this.checkBox5.Text = "1000";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // tBTen1
            // 
            this.tBTen1.Location = new System.Drawing.Point(450, 91);
            this.tBTen1.Name = "tBTen1";
            this.tBTen1.Size = new System.Drawing.Size(100, 20);
            this.tBTen1.TabIndex = 11;
            // 
            // tBten5
            // 
            this.tBten5.Location = new System.Drawing.Point(450, 118);
            this.tBten5.Name = "tBten5";
            this.tBten5.Size = new System.Drawing.Size(100, 20);
            this.tBten5.TabIndex = 12;
            // 
            // tBhun1
            // 
            this.tBhun1.Location = new System.Drawing.Point(450, 145);
            this.tBhun1.Name = "tBhun1";
            this.tBhun1.Size = new System.Drawing.Size(100, 20);
            this.tBhun1.TabIndex = 13;
            // 
            // tBhun5
            // 
            this.tBhun5.Location = new System.Drawing.Point(450, 172);
            this.tBhun5.Name = "tBhun5";
            this.tBhun5.Size = new System.Drawing.Size(100, 20);
            this.tBhun5.TabIndex = 14;
            // 
            // tBthous
            // 
            this.tBthous.Location = new System.Drawing.Point(450, 199);
            this.tBthous.Name = "tBthous";
            this.tBthous.Size = new System.Drawing.Size(100, 20);
            this.tBthous.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 265);
            this.Controls.Add(this.tBthous);
            this.Controls.Add(this.tBhun5);
            this.Controls.Add(this.tBhun1);
            this.Controls.Add(this.tBten5);
            this.Controls.Add(this.tBTen1);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonLoadSum);
            this.Controls.Add(this.buttonDown);
            this.Controls.Add(this.buttonPIN);
            this.Controls.Add(this.textBoxPIN);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelBankomatData);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelBankomatData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxPIN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonPIN;
        private System.Windows.Forms.Button buttonDown;
        private System.Windows.Forms.Button buttonLoadSum;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.TextBox tBTen1;
        private System.Windows.Forms.TextBox tBten5;
        private System.Windows.Forms.TextBox tBhun1;
        private System.Windows.Forms.TextBox tBhun5;
        private System.Windows.Forms.TextBox tBthous;
    }
}

