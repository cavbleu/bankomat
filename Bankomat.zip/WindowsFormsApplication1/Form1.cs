﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using Bank;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Bankomat bankomat;
        public Form1()
        {
            InitializeComponent();
            bankomat = new Bankomat();
            bankomat.BankomatMessageEvent += Bankomat_MessageEvent;
            bankomat.BankomatStartEvent += Bankomat_Start;
            bankomat.BankomatStopEvent += Bankomat_Stop;
        }
        private void ShowBankomatData()
        {
            labelBankomatData.Text = bankomat.ToString();
        }
        private void PIN()
        {
            int pin;
            int.TryParse(textBoxPIN.Text, out pin);
            bankomat.PIN(pin);
            ShowBankomatData();
        }
        private void DownMoney()
        {
            int money, moneyCur, moneySum;
            try
            {
                moneyCur = Convert.ToInt32(tBhun1.Text) * 100 + Convert.ToInt32(tBhun5.Text) * 500 + Convert.ToInt32(tBTen1.Text) * 10 + Convert.ToInt32(tBten5.Text) * 50 + Convert.ToInt32(tBthous.Text) * 1000;
                moneySum = bankomat.Sumhundred1 * 100 + bankomat.Sumhundred5 * 500 + bankomat.Sumten1 * 10 + bankomat.Sumten5 * 50 + bankomat.Sumthousand1 * 1000;
                if (moneyCur <= bankomat.SumMoneyID && moneyCur<=moneySum)
                {
                    if (tBhun1.Text != null || tBhun5.Text != null || tBTen1.Text != null || tBten5.Text != null || tBthous.Text != null)
                    {
                        if (checkBox1.Checked)
                        {
                            int.TryParse(tBTen1.Text, out money); if (bankomat.Sumten1 >= money) { bankomat.DownMoneyTen1(money); } else { moneyCur -= money * 10; }
                        }
                        if (checkBox2.Checked)
                        {
                            int.TryParse(tBten5.Text, out money); if (bankomat.Sumten5 >= money) { bankomat.DownMoneyTen5(money); } else { moneyCur -= money * 50; }
                        }
                        if (checkBox3.Checked)
                        {
                            int.TryParse(tBhun1.Text, out money); if (bankomat.Sumhundred1 >= money) { bankomat.DownMoneyHundred1(money); } else { moneyCur -= money * 100; }
                        }
                        if (checkBox4.Checked)
                        {
                            int.TryParse(tBhun5.Text, out money); if (bankomat.Sumhundred5 >= money) { bankomat.DownMoneyHundred5(money); } else { moneyCur -= money * 500; }
                        }
                        if (checkBox5.Checked)
                        {
                            int.TryParse(tBthous.Text, out money); if (bankomat.Sumthousand1 >= money) { bankomat.DownMoneyThousand1(money); } else { moneyCur -= money * 1000; }
                        }
                        bankomat.DownMoneySum(moneyCur);
                    }
                    else
                        ShowBankomatData();
                }
                else
                { MessageBox.Show("Недостаточно средств!"); }
            }
            catch { MessageBox.Show("Невозможно снять введенную сумму!"); }
        }
        private void EndWork()
        {
            bankomat.EndWork();
            ShowBankomatData();
        }
        private void LoadMoney()
        {
            int money, moneySum;
            moneySum = 0;
            if (tBhun1.Text != null || tBhun5.Text != null || tBTen1.Text != null || tBten5.Text != null || tBthous.Text != null)
            {
                if (checkBox1.Checked)
                {
                    int.TryParse(tBTen1.Text, out money); bankomat.LoadMoneyTen1(money); moneySum += money * 10;
                }
                if (checkBox2.Checked)
                {
                    int.TryParse(tBten5.Text, out money); bankomat.LoadMoneyTen5(money); moneySum += money * 50;
                }
                if (checkBox3.Checked)
                {
                    int.TryParse(tBhun1.Text, out money); bankomat.LoadMoneyHundred1(money); moneySum += money * 100;
                }
                if (checkBox4.Checked)
                {
                    int.TryParse(tBhun5.Text, out money); bankomat.LoadMoneyHundred5(money); moneySum += money * 500;
                }
                if (checkBox4.Checked)
                {
                    int.TryParse(tBthous.Text, out money); bankomat.LoadMoneyThousand1(money); moneySum += money * 1000;
                }
                    bankomat.LoadMoneySum(moneySum);
            }
            else
                ShowBankomatData();
        }
        

        private void Bankomat_MessageEvent(object sender, BankomatEventArgs e)
        {
            MessageBox.Show(e.Message);
        }
        private void Bankomat_Start(object sender, BankomatEventArgs e)
        {
            timer1.Start();
        }
        private void Bankomat_Stop(object sender, BankomatEventArgs e)
        {
            timer1.Stop();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Моделирование работы банкомата";
            ShowBankomatData();
            textBoxPIN.Text = bankomat.PinKod.ToString();
            tBthous.Text = bankomat.CurMthousand1.ToString();
            tBhun1.Text = bankomat.CurMhundred1.ToString();
            tBhun5.Text = bankomat.CurMhundred5.ToString();
            tBTen1.Text = bankomat.CurMten1.ToString();
            tBten5.Text = bankomat.CurMten5.ToString();
            timer1.Interval = 5000;
        }
        private void buttonPIN_Click(object sender, EventArgs e)
        {
            PIN();
            Thread.Sleep(1000);
            PIN();
        }

        private void buttonDown_Click(object sender, EventArgs e)
        {
            
            if (Convert.ToInt32(tBthous.Text) <= 40)///
                DownMoney();
            else
                MessageBox.Show("Не возможно снять сумму свыше 40");
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            EndWork();
        }

        private void buttonLoadSum_Click(object sender, EventArgs e)
        {
            LoadMoney();
            EndWork();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            bankomat.BankomatWork();
            ShowBankomatData();
        }

    }
}
