﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    class OperState : IBankomatState
    {
        string name = "Выполнение_Операций";
        public string Name
        {
            get { return name; }
        }

        public void PIN(Bankomat bankomat, int pin)
        {
            const string message = "Вводить Пин-код не нужно";
            bankomat.OnMessageEvent(message);
        }
        public void DownMoneyThousand1(Bankomat bankomat, int money)
        {
            const string message = "В банкомате недостаточно средств";
            bankomat.CurMthousand1 = Math.Abs(money);
            if (bankomat.CurMthousand1 <= bankomat.Sumthousand1)
            {
                bankomat.Sumthousand1 -= bankomat.CurMthousand1;
            }
            else bankomat.OnMessageEvent(message);
            if (bankomat.Sumthousand1 == 0) bankomat.SetState(StateType.Заблокирован);
        }

        public void DownMoneyHundred1(Bankomat bankomat, int money)
        {
            const string message = "В банкомате недостаточно средств";
            bankomat.CurMhundred1 = Math.Abs(money);
            if (bankomat.CurMhundred1 <= bankomat.Sumhundred1)
            {
                bankomat.Sumhundred1 -= bankomat.CurMhundred1;
            }
            else bankomat.OnMessageEvent(message);
            if (bankomat.Sumhundred1 == 0) bankomat.SetState(StateType.Заблокирован);
        }

        public void DownMoneyHundred5(Bankomat bankomat, int money)
        {
            const string message = "В банкомате недостаточно средств";
            bankomat.CurMhundred5 = Math.Abs(money);
            if (bankomat.CurMhundred5 <= bankomat.Sumhundred5)
            {
                bankomat.Sumhundred5 -= bankomat.CurMhundred5;
            }
            else bankomat.OnMessageEvent(message);
            if (bankomat.Sumhundred5 == 0) bankomat.SetState(StateType.Заблокирован);
        }

        public void DownMoneyTen1(Bankomat bankomat, int money)
        {
            const string message = "В банкомате недостаточно средств";
            bankomat.CurMten1 = Math.Abs(money);
            if (bankomat.CurMten1 <= bankomat.Sumten1)
            {
                bankomat.Sumten1 -= bankomat.CurMten1;
            }
            else bankomat.OnMessageEvent(message);
            if (bankomat.Sumten1 == 0) bankomat.SetState(StateType.Заблокирован);
        }

        public void DownMoneyTen5(Bankomat bankomat, int money)
        {
            const string message = "В банкомате недостаточно средств";
            bankomat.CurMten5 = Math.Abs(money);
            if (bankomat.CurMten5 <= bankomat.Sumten5)
            {
                bankomat.Sumten5 -= bankomat.CurMten5;
            }
            else bankomat.OnMessageEvent(message);
            if (bankomat.Sumten5 == 0) bankomat.SetState(StateType.Заблокирован);
        }
        public void DownMoneySum(Bankomat bankomat, int money)//доработать
        {
            const string message = "В банкомате недостаточно средств";
            bankomat.CurMoneyID = Math.Abs(money);
            if (bankomat.CurMoneyID <= bankomat.SumMoneyID)
            {
                bankomat.SumMoneyID -= bankomat.CurMoneyID;
            }
            else bankomat.OnMessageEvent(message);
            if (bankomat.CurMoneyID == 0) bankomat.SetState(StateType.Заблокирован);
        }
        public void EndWork(Bankomat bankomat)
        {
            bankomat.SetState(StateType.Ожидание);
            bankomat.OnStopEvent();
        }
        public void LoadMoneyThousand1(Bankomat bankomat, int money)
        {
            bankomat.CurMthousand1 = Math.Abs(money);
            bankomat.Sumthousand1 += bankomat.CurMthousand1;
            bankomat.SetState(StateType.Ожидание);
            bankomat.OnStopEvent();
        }

        public void LoadMoneyHundred1(Bankomat bankomat, int money)
        {
            bankomat.CurMhundred1 = Math.Abs(money);
            bankomat.Sumhundred1 += bankomat.CurMhundred1;
            bankomat.SetState(StateType.Ожидание);
            bankomat.OnStopEvent();
        }

        public void LoadMoneyHundred5(Bankomat bankomat, int money)
        {
            bankomat.CurMhundred5 = Math.Abs(money);
            bankomat.Sumhundred5 += bankomat.CurMhundred5;
            bankomat.SetState(StateType.Ожидание);
            bankomat.OnStopEvent();
        }

        public void LoadMoneyTen1(Bankomat bankomat, int money)
        {
            bankomat.CurMten1 = Math.Abs(money);
            bankomat.Sumten1 += bankomat.CurMten1;
            bankomat.SetState(StateType.Ожидание);
            bankomat.OnStopEvent();
        }

        public void LoadMoneyTen5(Bankomat bankomat, int money)
        {
            bankomat.CurMten5 = Math.Abs(money);
            bankomat.Sumten5 += bankomat.CurMten1;
            bankomat.SetState(StateType.Ожидание);
            bankomat.OnStopEvent();
        }
        
        public void LoadMoneySum(Bankomat bankomat, int money)
        {
            bankomat.CurMoneyID = Math.Abs(money);
            bankomat.CurMoneyID += bankomat.SumMoneyID;
            bankomat.SetState(StateType.Ожидание);
            bankomat.OnStopEvent();
        }

    }
}
