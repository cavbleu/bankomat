﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    public class BankomatEventArgs : EventArgs
    {
        public string Message { get; set; }
    }
}
