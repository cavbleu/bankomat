﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    class AutState : IBankomatState
    {
        string name = "Аутентификация";
        public string Name
        {
            get { return name; }
        }
        public void PIN(Bankomat bankomat, int pin)
        {
            const string message = "Пин-код неверен";
            if (pin == bankomat.PinKod)
            {
                bankomat.SetState(StateType.Выполнение_Операций);
                bankomat.OnStartEvent();
            }
            else bankomat.OnMessageEvent(message);
        }
        public void DownMoneyThousand1(Bankomat bankomat, int money)
        {
            const string message = "Выполнение операций невозможно, идет аутентификация";
            bankomat.OnMessageEvent(message);
        }

        public void DownMoneyHundred1(Bankomat bankomat, int money)
        {
            const string message = "Выполнение операций невозможно, идет аутентификация";
            bankomat.OnMessageEvent(message);
        }

        public void DownMoneyHundred5(Bankomat bankomat, int money)
        {
            const string message = "Выполнение операций невозможно, идет аутентификация";
            bankomat.OnMessageEvent(message);
        }

        public void DownMoneyTen1(Bankomat bankomat, int money)
        {
            const string message = "Выполнение операций невозможно, идет аутентификация";
            bankomat.OnMessageEvent(message);
        }

        public void DownMoneyTen5(Bankomat bankomat, int money)
        {
            const string message = "Выполнение операций невозможно, идет аутентификация";
            bankomat.OnMessageEvent(message);
        }
        public void DownMoneySum(Bankomat bankomat, int money)
        {
            const string message = "Выполнение операций невозможно, идет аутентификация";
            bankomat.OnMessageEvent(message);
        }
        public void EndWork(Bankomat bankomat)
        {
            bankomat.SetState(StateType.Ожидание);
            bankomat.OnStopEvent();
        }
        public void LoadMoneyThousand1(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }

        public void LoadMoneyHundred1(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }

        public void LoadMoneyHundred5(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }

        public void LoadMoneyTen1(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }

        public void LoadMoneyTen5(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }

        public void LoadMoneySum(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }
    }
}
