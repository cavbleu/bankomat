﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    class LockState : IBankomatState
    {
        string name = "Заблокирован";
        public string Name
        {
            get { return name; }
        }
        public void PIN(Bankomat bankomat, int pin)
        {
            const string message = "Работа невозможна, заблокирован";
            bankomat.OnMessageEvent(message);
        }
        /// <summary>
        /// сбор денег
        /// </summary>
        /// <param name="bankomat"></param>
        /// <param name="money"></param>
        public void DownMoneyThousand1(Bankomat bankomat, int money)
        {
            const string message = "Работа невозможна, нет денег или заблокирован";
            bankomat.OnMessageEvent(message);
        }

        /// <summary>
        /// сбор денег
        /// </summary>
        /// <param name="bankomat"></param>
        /// <param name="money"></param>
        public void DownMoneyHundred1(Bankomat bankomat, int money)
        {
            const string message = "Работа невозможна, нет денег или заблокирован";
            bankomat.OnMessageEvent(message);
        }

        /// <summary>
        /// сбор денег
        /// </summary>
        /// <param name="bankomat"></param>
        /// <param name="money"></param>
        public void DownMoneyHundred5(Bankomat bankomat, int money)
        {
            const string message = "Работа невозможна, нет денег или заблокирован";
            bankomat.OnMessageEvent(message);
        }

        /// <summary>
        /// сбор денег
        /// </summary>
        /// <param name="bankomat"></param>
        /// <param name="money"></param>
        public void DownMoneyTen1(Bankomat bankomat, int money)
        {
            const string message = "Работа невозможна, нет денег или заблокирован";
            bankomat.OnMessageEvent(message);
        }

        /// <summary>
        /// сбор денег
        /// </summary>
        /// <param name="bankomat"></param>
        /// <param name="money"></param>
        public void DownMoneyTen5(Bankomat bankomat, int money)
        {
            const string message = "Работа невозможна, нет денег или заблокирован";
            bankomat.OnMessageEvent(message);
        }

        /// <summary>
        /// сбор денег
        /// </summary>
        /// <param name="bankomat"></param>
        /// <param name="money"></param>
        public void DownMoneySum(Bankomat bankomat, int money)
        {
            const string message = "Работа невозможна, нет денег или заблокирован";
            bankomat.OnMessageEvent(message);
        }
        /// <summary>
        /// блокировка работы
        /// </summary>
        /// <param name="bankomat"></param>
        public void EndWork(Bankomat bankomat)
        {
            const string message = "Работа невозможна, заблокирован";
            bankomat.OnMessageEvent(message);
        }
        /// <summary>
        /// хагрузка денег
        /// </summary>
        /// <param name="bankomat"></param>
        /// <param name="money"></param>
        public void LoadMoneyThousand1(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }

        /// <summary>
        /// хагрузка денег
        /// </summary>
        /// <param name="bankomat"></param>
        /// <param name="money"></param>
        public void LoadMoneyHundred1(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }

        /// <summary>
        /// хагрузка денег
        /// </summary>
        /// <param name="bankomat"></param>
        /// <param name="money"></param>
        public void LoadMoneyHundred5(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }

        /// <summary>
        /// хагрузка денег
        /// </summary>
        /// <param name="bankomat"></param>
        /// <param name="money"></param>
        public void LoadMoneyTen1(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }

        /// <summary>
        /// хагрузка денег
        /// </summary>
        /// <param name="bankomat"></param>
        /// <param name="money"></param>
        public void LoadMoneyTen5(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }

        public void LoadMoneySum(Bankomat bankomat, int money)
        {
            const string message = "Загружать деньги/Разблокировать не требуется";
            bankomat.OnMessageEvent(message);
        }
    }
}
