﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    public class Bankomat
    {
        public int ID { get; set; } //ID пользователя
        public int CurMthousand1 { get; set; } //Заданная сумма для снятия тысяч

        public int CurMhundred1 { get; set; } //Заданная сумма для снятия сотен
        public int CurMhundred5 { get; set; } //Заданная сумма для снятия 5 сотен
        public int CurMten1 { get; set; } //Заданная сумма для снятия десятков
        public int CurMten5 { get; set; } //Заданная сумма для снятия 5 десятков

        public int SumMoneyID { get; set; }
        public int CurMoneyID { get; set; }

        public int PinKod { get; private set; } //PIN-код для аутентификации

        public int Sumthousand1 { get; set; }//тысячи

        public int Sumhundred1 {get; set;}//сотни

        public int Sumhundred5 { get; set; }//500 сотен

        public int Sumten1 { get; set; }//1 десяток

        public int Sumten5 { get; set; }//5 десятков

        IBankomatState state;
        double chanceConnection;
        Random rnd;

        public event EventHandler<BankomatEventArgs> BankomatMessageEvent;
        public event EventHandler<BankomatEventArgs> BankomatStartEvent;
        public event EventHandler<BankomatEventArgs> BankomatStopEvent;

        public Bankomat()
        {
            ID = 1;
            Sumthousand1 = 100;
            Sumhundred1 = 200;
            Sumhundred5 = 200;
            Sumten1 = 500;
            Sumten5 = 200;
            SumMoneyID = 58600;
            CurMthousand1 = 0;
            CurMhundred1 = 0;
            CurMhundred5 = 0;
            CurMten1 = 0;
            CurMten5 = 0;
            CurMoneyID = 0;
            PinKod = 1111;
            chanceConnection = 0.04;
            state = new WaitState();
            rnd = new Random();
        }
        public void BankomatNoConnection()
        {
            if (rnd.NextDouble() < chanceConnection)
            {
                SetState(StateType.Заблокирован);
                OnStopEvent();
            }
        }
        public void BankomatWork()
        {
            BankomatNoConnection();
        }
        public void PIN(int pin)
        {
            this.state.PIN(this, pin);
        }
        public void DownMoneyThousand1(int money)
        {
            if (money >= 0)
            {
                Sumthousand1 -= money;
                this.state.DownMoneyThousand1(this, money);
            }
        }

        public void DownMoneyHundred1(int money)
        {
            if (money >= 0)
            {
                Sumhundred1 -= money;
                this.state.DownMoneyHundred1(this, money);
            }
        }

        public void DownMoneyHundred5(int money)
        {
            if (money >= 0)
            {
                Sumhundred5 -= money;
                this.state.DownMoneyHundred5(this, money);
            }
        }

        public void DownMoneyTen1(int money)
        {
            if (money >= 0)
            {
                Sumten1 -= money;
                this.state.DownMoneyTen1(this, money);
            }
        }

        public void DownMoneySum(int money)
        {
            if (money >= 0)
            {
                SumMoneyID -= money;
                this.state.DownMoneySum(this, money);
            }
        }

        public void DownMoneyTen5(int money)
        {
            if (money >= 0)
            {
                Sumten5 -= money;
                this.state.DownMoneyTen5(this, money);
            }
        }

        public void EndWork()
        {
            this.state.EndWork(this);
        }

        /// <summary>
        /// загружает деньги
        /// </summary>
        /// <param name="money"></param>
        public void LoadMoneyThousand1(int money)
        {
            if (money >= 0 && (money + Sumthousand1 <= 100))
            {

                this.state.LoadMoneyThousand1(this, money);
            }
        }

        /// <summary>
        /// загружает деньги
        /// </summary>
        /// <param name="money"></param>
        public void LoadMoneyHundred1(int money)
        {
            if (money >= 0 && (money + Sumhundred1 <= 200))
            {

                this.state.LoadMoneyHundred1(this, money);
            }
        }

        /// <summary>
        /// загружает деньги
        /// </summary>
        /// <param name="money"></param>
        public void LoadMoneyHundred5(int money)
        {
            if (money >= 0 && (money + Sumhundred5 <= 200))
            {

                this.state.LoadMoneyHundred5(this, money);
            }
        }

        /// <summary>
        /// загружает деньги
        /// </summary>
        /// <param name="money"></param>
        public void LoadMoneyTen1(int money)
        {
            if (money >= 0 && (money + Sumten1 <= 500))
            {

                this.state.LoadMoneyTen1(this, money);
            }
        }

        /// <summary>
        /// загружает деньги
        /// </summary>
        /// <param name="money"></param>
        public void LoadMoneyTen5(int money)
        {
            if (money >= 0 && (money + Sumten5 <= 200))
            {

                this.state.LoadMoneyTen5(this, money);
            }
        }

        /// <summary>
        /// загружает деньги
        /// </summary>
        /// <param name="money"></param>
        public void LoadMoneySum(int money)
        {
            if (money >= 0)
            {
                this.state.LoadMoneySum(this, money);
            }
        }

        public void OnMessageEvent(string message)
        {
            BankomatEventArgs e = new BankomatEventArgs() { Message = message };
            BankomatMessageEvent.Invoke(this, e);
        }
        public void OnStartEvent()
        {
            BankomatEventArgs e = new BankomatEventArgs();
            BankomatStartEvent.Invoke(this, e);
        }
        public void OnStopEvent()
        {
            BankomatEventArgs e = new BankomatEventArgs();
            BankomatStopEvent.Invoke(this, e);
        }

        /// <summary>
        /// статус банкомата
        /// </summary>
        /// <param name="stateType"></param>
        public void SetState(StateType stateType)
        {
            switch (stateType)
            {
                case StateType.Ожидание:
                    state = new WaitState(); break;
                case StateType.Аутентификация_Пользователя:
                    state = new AutState(); break;
                case StateType.Выполнение_Операций:
                    state = new OperState(); break;
                case StateType.Заблокирован:
                    state = new LockState(); break;
            }
        }
        public override string ToString()
        {
            return string.Format("Данные о банкомате:\n" +
                                 "* ID: {0}\n" +
                                 "* Баланс {13}\n" +
                                 "* Pin-код: {1}\n" +
                                 "* Кол-во 10 рублевых:     {2}\n" +
                                 "* Кол-во 50 рублевых:     {3}\n" +
                                 "* Кол-во 100 рублевых:   {4}\n" +
                                 "* Кол-во 500 рублевых:   {5}\n" +
                                 "* Кол-во 1000 рублевых: {6}\n" +
                                 "* Сумма для снятия 10 рублевых:      {7}\n" +
                                 "* Сумма для снятия 50 рублевых:      {8}\n" +
                                 "* Сумма для снятия 100 рублевых:    {9}\n" +
                                 "* Сумма для снятия 500 рублевых:    {10}\n" +
                                 "* Сумма для снятия 1000 рублевых:  {11}\n" +
                                 "* Состояние:             {12}\n", 
                                 ID, PinKod, Sumten1, Sumten5, 
                                 Sumhundred1, Sumhundred5,
                                 Sumthousand1,
                                 CurMten1, CurMten5,
                                 CurMhundred1, CurMhundred5,
                                 CurMthousand1,
                                 state.Name, SumMoneyID);
        }
    }
}
