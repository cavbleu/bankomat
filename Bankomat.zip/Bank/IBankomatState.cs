﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    interface IBankomatState
    {
        string Name { get; }
        void PIN(Bankomat bankomat, int pin);
        void DownMoneyThousand1(Bankomat bankomat, int money);
        void DownMoneyHundred1(Bankomat bankomat, int money);
        void DownMoneyHundred5(Bankomat bankomat, int money);
        void DownMoneyTen1(Bankomat bankomat, int money);
        void DownMoneyTen5(Bankomat bankomat, int money);
        void DownMoneySum(Bankomat bankomat, int money);
        void EndWork(Bankomat bankomat);
        void LoadMoneyThousand1(Bankomat bankomat,int money);
        void LoadMoneyHundred1(Bankomat bankomat, int money);
        void LoadMoneyHundred5(Bankomat bankomat, int money);
        void LoadMoneyTen1(Bankomat bankomat, int money);
        void LoadMoneyTen5(Bankomat bankomat, int money);
        void LoadMoneySum(Bankomat bankomat, int money);

    }
}
