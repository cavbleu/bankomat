﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    class WaitState : IBankomatState
    {
        string name = "Ожидание";
        public string Name
        {
            get { return name; }
        }

        public void PIN(Bankomat bankomat, int pin)
        {
            bankomat.SetState(StateType.Аутентификация_Пользователя);
        }
        public void DownMoneyThousand1(Bankomat bankomat, int money)
        {
            const string message = "Вы не вошли в систему";
            bankomat.OnMessageEvent(message);
        }

        public void DownMoneyHundred1(Bankomat bankomat, int money)
        {
            const string message = "Вы не вошли в систему";
            bankomat.OnMessageEvent(message);
        }

        public void DownMoneyHundred5(Bankomat bankomat, int money)
        {
            const string message = "Вы не вошли в систему";
            bankomat.OnMessageEvent(message);
        }

        public void DownMoneyTen1(Bankomat bankomat, int money)
        {
            const string message = "Вы не вошли в систему";
            bankomat.OnMessageEvent(message);
        }

        public void DownMoneyTen5(Bankomat bankomat, int money)
        {
            const string message = "Вы не вошли в систему";
            bankomat.OnMessageEvent(message);
        }

        public void DownMoneySum(Bankomat bankomat, int money)
        {
            const string message = "Вы не вошли в систему";
            bankomat.OnMessageEvent(message);
        }

        public void EndWork(Bankomat bankomat)
        {
            const string message = "Вы не вошли в систему";
            bankomat.OnMessageEvent(message);
        }
        public void LoadMoneyThousand1(Bankomat bankomat, int money)
        {
            bankomat.CurMthousand1 = Math.Abs(money);
            bankomat.Sumthousand1 += bankomat.CurMthousand1;
        }

        public void LoadMoneyHundred1(Bankomat bankomat, int money)
        {
            bankomat.CurMhundred1 = Math.Abs(money);
            bankomat.Sumhundred1 += bankomat.CurMhundred1;
        }

        public void LoadMoneyHundred5(Bankomat bankomat, int money)
        {
            bankomat.CurMhundred5 = Math.Abs(money);
            bankomat.Sumhundred5 += bankomat.CurMhundred5;
        }

        public void LoadMoneyTen1(Bankomat bankomat, int money)
        {
            bankomat.CurMten1 = Math.Abs(money);
            bankomat.Sumten1 += bankomat.CurMten1;
        }

        public void LoadMoneyTen5(Bankomat bankomat, int money)
        {
            bankomat.CurMten5 = Math.Abs(money);
            bankomat.Sumten5 += bankomat.CurMten5;
        }

        public void LoadMoneySum(Bankomat bankomat, int money)
        {
            bankomat.CurMoneyID = Math.Abs(money);
            bankomat.SumMoneyID += bankomat.CurMoneyID;
        }
    }
}
